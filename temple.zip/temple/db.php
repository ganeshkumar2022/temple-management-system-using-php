<?php
$con=mysqli_connect("localhost","root","","temple");
if(!$con)
{
    die("Error to connect database :".mysqli_connect_error());
}
?>