<table class="header-first" id="scrolls-up-o">
    <tr>
        <th><i class="fa-solid fa-phone"></i> 9089912345</th>
        <th style="font-weight:normal;">Rastrikwada temple</th>
        <th class="social-me"><i class="fa-brands fa-facebook-f"></i></th>
        <th class="social-me"><i class="fa-brands fa-twitter"></i></th>
        <th class="social-me"><i class="fa-brands fa-square-instagram"></i></th>
        <th class="social-me"><i class="fa-brands fa-linkedin-in"></i></th>
        <th style="border-right:1px solid #061f59;"></th>
    </tr>
</table>
<nav class="navbar navbar-expand-md myheader-two navbar-light">
  <!-- Brand -->
  <a class="navbar-brand" href="index.php"><img src="assets/images/main_logo.png" style="height:55px;"></a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About us</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="index.php#seva">Seva</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="pass.php">Pass</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="complaint.php">Complaint</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact us</a>
      </li>
    </ul>
  </div>
</nav>