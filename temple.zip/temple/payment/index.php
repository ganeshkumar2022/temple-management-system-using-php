<?php
echo "<script>window.location.replace('pay.php?checkout=manual');</script>";
?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="utf-8">
</head>
<body>
    <form id="checkout-selection" method="POST">
        <input type="radio" name="checkout" value="automatic">Automatic Checkout Demo<br>
        <input type="radio" name="checkout" value="orders">Manual Checkout Demo<br>
        <input type="submit" value="Submit">
    </form>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script>
        jQuery(document).ready(function($)
        {
            var form = $('#checkout-selection');
            var radio = $('input[name="checkout"]');
            var choice = '';

            radio.change(function(e)
            {
                choice = this.value;
                if (choice === 'orders')
                {
                    form.attr('action', 'pay.php?checkout=manual');
                }
                else
                {
                    form.attr('action', 'pay.php?checkout=automatic');
                }
            });
        });
    </script>

</body>
</html>
